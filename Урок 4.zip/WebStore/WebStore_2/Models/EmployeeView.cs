﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WebStore_2.Models
{
    public class EmployeeView
    {
        public int Id { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Фамилия является обязательным")]
        [Display(Name = "Фамилия")]
        public string LastName { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Имя является обязательным")]
        [Display(Name = "Имя")]
        [StringLength(maximumLength: 200, MinimumLength = 2, ErrorMessage = "Количество символов в имени может быть от 2 до 200")]
        public string FirstName { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Возрост является обязательным")]
        [Display(Name = "Возрост")]
        public int Age { get; set; }
    }
}
