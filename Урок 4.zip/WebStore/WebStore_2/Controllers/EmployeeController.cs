﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebStore_2.Models;
using WebStore_2.Infrastructure.Interfaces;

namespace WebStore_2.Controllers
{
    [Route("Employees")]
    public class EmployeeController : Controller
    {
        private readonly IEmployeesData _employees;
        public EmployeeController(IEmployeesData employees)
        {
            _employees = employees;
        }
        public IActionResult Index()
        {
            return View(_employees.GetAll());
        }
        [Route("Edit/{Id?}")]
        public IActionResult Edit(int? id)
        {
            EmployeeView emp;
            if (id.HasValue)
            {
                emp = _employees.GetById(id.Value);
                if(emp == null)
                {
                    return NotFound();
                }
            }
            else
            {
                emp = new EmployeeView();
            }
            return View(emp);
        }

        [HttpPost]
        [Route("Edit/{Id?}")]
        public IActionResult Edit(EmployeeView model)
        {
            if(model.Age < 18 && model.Age > 75)
            {
                ModelState.AddModelError("Age", "Ошибка возраста!");
            }
            if (ModelState.IsValid)
            {
                if (model.Id > 0)
                {
                    EmployeeView emp = _employees.GetById(model.Id);
                    if (emp != null)
                    {
                        emp.LastName = model.LastName;
                        emp.FirstName = model.FirstName;
                        emp.Age = model.Age;
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                else
                {
                    _employees.AddNew(model);
                }
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }
        [Route("Delete/{Id}")]
        public IActionResult Delete(int id)
        {
            _employees.Delete(id);
            return RedirectToAction(nameof(Index));
        }

    }
}