﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebStore_2.Models;

namespace WebStore_2.Infrastructure.Interfaces
{
    public interface IEmployeesData
    {
        IEnumerable<EmployeeView> GetAll();
        EmployeeView GetById(int id);
        void AddNew(EmployeeView model);
        void Delete(int id);
    }
}
