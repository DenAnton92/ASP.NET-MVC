﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebStore_2.Models;

namespace WebStore_2.Infrastructure.Implementations
{
    public class InMemoryemployeesData : Interfaces.IEmployeesData
    {
        private readonly List<EmployeeView> _employees;
        public InMemoryemployeesData()
        {
            _employees = new List<EmployeeView> {
            new EmployeeView { Id = 1, LastName = "Иванов", FirstName = "Иван", Age = 18 },
            new EmployeeView { Id = 2, LastName = "Петров", FirstName = "Петр", Age = 19 },
            new EmployeeView { Id = 3, LastName = "Сидоров", FirstName = "Сидор", Age = 20 },
            new EmployeeView { Id = 4, LastName = "Николаев", FirstName = "Николай", Age = 21 }
            };
        }
        public void AddNew(EmployeeView model)
        {
            model.Id = _employees.Max(e => e.Id) + 1;
            _employees.Add(model);
        }

        public void Delete(int id)
        {
            var emp = GetById(id);
            if(emp != null) _employees.Remove(emp);
        }

        public IEnumerable<EmployeeView> GetAll()
        {
            return _employees;
        }

        public EmployeeView GetById(int id)
        {
            return _employees.Where(e => e.Id == id).FirstOrDefault();
        }
    }
}
